package klu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalS21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
