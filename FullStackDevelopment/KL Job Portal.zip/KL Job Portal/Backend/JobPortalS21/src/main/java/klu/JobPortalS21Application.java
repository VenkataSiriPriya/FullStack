package klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalS21Application {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalS21Application.class, args);
	}

}
